/*Calvin(Jinghao) Fu, jfu14@u.rochester.edu, Jan 18th 2022, Say Hello
 */

public class SayHello {
	public static void main (String[] args) {
		System.out.println("My name is Calvin Fu");
		System.out.println("jfu14@u.rochester.edu");
		System.out.println("I'd like to learn computer science in general and the java programming language");
		
		//print your full name, your school email, and something you would like to learn by taking this class.
	}

}
